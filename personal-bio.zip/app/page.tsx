"use client"

import { useState } from "react"
import { Github, Linkedin, Facebook, MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"

export default function Portfolio() {
  const [activeSection, setActiveSection] = useState("about")

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId)
    const element = document.getElementById(sectionId)
    element?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <div className="min-h-screen bg-[#1a2332] text-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-[#1a2332]/90 backdrop-blur-sm border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <div className="bg-red-600 w-12 h-12 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-xl">A</span>
              </div>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <button
                  onClick={() => scrollToSection("about")}
                  className="text-red-500 hover:text-red-400 px-3 py-2 text-sm font-medium"
                >
                  <span className="text-red-500">01.</span> About
                </button>
                <button
                  onClick={() => scrollToSection("experience")}
                  className="text-gray-300 hover:text-red-400 px-3 py-2 text-sm font-medium"
                >
                  <span className="text-red-500">02.</span> Experience
                </button>
                <button
                  onClick={() => scrollToSection("work")}
                  className="text-gray-300 hover:text-red-400 px-3 py-2 text-sm font-medium"
                >
                  <span className="text-red-500">03.</span> Work
                </button>
                <button
                  onClick={() => scrollToSection("contact")}
                  className="text-gray-300 hover:text-red-400 px-3 py-2 text-sm font-medium"
                >
                  <span className="text-red-500">04.</span> Contact
                </button>
                <Button variant="outline" className="border-red-500 text-red-500 hover:bg-red-500 hover:text-white">
                  Resume
                </Button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Social Links Sidebar */}
      <div className="fixed left-8 bottom-0 z-40 hidden lg:flex flex-col items-center space-y-6">
        <a href="https://github.com" className="text-gray-400 hover:text-red-500 transition-colors">
          <Github size={20} />
        </a>
        <a href="https://linkedin.com" className="text-gray-400 hover:text-red-500 transition-colors">
          <Linkedin size={20} />
        </a>
        <a href="https://facebook.com" className="text-gray-400 hover:text-red-500 transition-colors">
          <Facebook size={20} />
        </a>
        <a href="https://wa.me" className="text-gray-400 hover:text-red-500 transition-colors">
          <MessageCircle size={20} />
        </a>
        <div className="w-px h-24 bg-gray-600"></div>
      </div>

      {/* Email Sidebar */}
      <div className="fixed right-8 bottom-0 z-40 hidden lg:flex flex-col items-center">
        <a
          href="mailto:contact@example.com"
          className="text-gray-400 hover:text-red-500 transition-colors writing-mode-vertical text-sm tracking-widest"
          style={{ writingMode: "vertical-rl" }}
        >
          contact@example.com
        </a>
        <div className="w-px h-24 bg-gray-600 mt-6"></div>
      </div>

      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl w-full">
          <div className="space-y-8">
            <div>
              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight">
                Hi<span className="text-red-500">,</span> I'm
              </h1>
              <h2 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-gray-300 mt-2">
                Your Name<span className="text-red-500">.</span>
              </h2>
              <h3 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-400 mt-4">
                I ensure things don't break<span className="text-red-500">.</span>
              </h3>
            </div>
            <p className="text-gray-400 text-lg max-w-2xl leading-relaxed">
              I'm a results-driven <span className="text-white font-semibold">Software Engineer</span> and{" "}
              <span className="text-white font-semibold">Full Stack Developer</span> based in Your City, with 5+ years
              of experience building scalable applications, defining development strategies, and integrating modern
              technologies to drive innovation.
            </p>
            <Button
              onClick={() => scrollToSection("contact")}
              variant="outline"
              className="border-red-500 text-red-500 hover:bg-red-500 hover:text-white px-8 py-3 text-lg"
            >
              Get In Touch
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center mb-12">
            <span className="text-red-500 font-mono text-xl mr-4">01.</span>
            <h2 className="text-3xl font-bold">About Me</h2>
            <div className="flex-1 h-px bg-gray-700 ml-8"></div>
          </div>

          <div className="grid lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2 space-y-6">
              <p className="text-gray-300 leading-relaxed">
                Hello! I'm Your Name, a results-driven{" "}
                <span className="text-white font-semibold">Software Engineer</span> and{" "}
                <span className="text-white font-semibold">Full Stack Developer</span> based in Your City, with over 5
                years of experience in the software development field.
              </p>

              <p className="text-gray-300 leading-relaxed">
                I specialize in building and leading high-performing development teams, defining robust software
                architectures, and driving innovation through the integration of modern technologies. My focus is on
                ensuring quality at scale, optimizing development processes, and leading successful digital
                transformations within organizations.
              </p>

              <p className="text-gray-300 leading-relaxed">
                Throughout my career, I've gained extensive exposure to the full development lifecycle, from designing
                systems and developing applications in my earlier roles to now leading departmental initiatives,
                mentoring large teams, and achieving significant improvements in performance and efficiency.
              </p>

              <p className="text-gray-300 leading-relaxed">
                I'm passionate about leveraging data and metrics to continuously improve quality and enjoy tackling
                complex challenges in areas like Web Development, Mobile Applications, Cloud Infrastructure, and DevOps.
                I hold a Bachelor's in Computer Science from <span className="text-red-500">Your University</span> and
                am currently pursuing advanced certifications.
              </p>

              <p className="text-gray-300 leading-relaxed">
                I currently apply these skills leading development efforts at{" "}
                <span className="text-red-500">Your Company</span>, contributing to impactful projects daily.
              </p>

              <p className="text-gray-300 leading-relaxed">
                My interests span a broad range of topics like Software Development, Web Technologies, Mobile
                Development, Cloud Computing, DevOps, Artificial Intelligence, and Data Science. I'm willing to learn
                new technologies, languages and skills, and looking forward to have new challenges.
              </p>

              <div className="mt-8">
                <p className="text-gray-300 mb-4">Here are a few tools/technologies I've been working with recently:</p>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <span className="text-red-500 mr-2">▸</span>
                      <span className="text-gray-300">JavaScript</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-red-500 mr-2">▸</span>
                      <span className="text-gray-300">TypeScript</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-red-500 mr-2">▸</span>
                      <span className="text-gray-300">React</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-red-500 mr-2">▸</span>
                      <span className="text-gray-300">Next.js</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-red-500 mr-2">▸</span>
                      <span className="text-gray-300">Node.js</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-red-500 mr-2">▸</span>
                      <span className="text-gray-300">Python</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <span className="text-red-500 mr-2">▸</span>
                      <span className="text-gray-300">PostgreSQL</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-red-500 mr-2">▸</span>
                      <span className="text-gray-300">MongoDB</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-red-500 mr-2">▸</span>
                      <span className="text-gray-300">AWS</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-red-500 mr-2">▸</span>
                      <span className="text-gray-300">Docker</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-red-500 mr-2">▸</span>
                      <span className="text-gray-300">Kubernetes</span>
                    </div>
                    <div className="flex items-center">
                      <span className="text-red-500 mr-2">▸</span>
                      <span className="text-gray-300">Git</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-1">
              <div className="relative">
                <div className="border-2 border-red-500 rounded-lg p-4">
                  <Image
                    src="/placeholder.svg?height=300&width=250"
                    alt="Profile"
                    width={250}
                    height={300}
                    className="rounded-lg grayscale hover:grayscale-0 transition-all duration-300"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center mb-12">
            <span className="text-red-500 font-mono text-xl mr-4">02.</span>
            <h2 className="text-3xl font-bold">Where I've Worked</h2>
            <div className="flex-1 h-px bg-gray-700 ml-8"></div>
          </div>

          <div className="flex flex-col lg:flex-row gap-8">
            <div className="lg:w-1/4">
              <div className="space-y-2">
                <button className="w-full text-left px-4 py-3 text-red-500 border-l-2 border-red-500 bg-red-500/10">
                  Your Company
                </button>
                <button className="w-full text-left px-4 py-3 text-gray-400 hover:text-red-500 hover:bg-red-500/5">
                  Previous Company
                </button>
                <button className="w-full text-left px-4 py-3 text-gray-400 hover:text-red-500 hover:bg-red-500/5">
                  Another Company
                </button>
              </div>
            </div>

            <div className="lg:w-3/4">
              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-semibold">
                    Senior Software Engineer <span className="text-red-500">@ Your Company</span>
                  </h3>
                  <p className="text-gray-400 text-sm">Jan 2022 - Present</p>
                </div>

                <div className="space-y-4">
                  <p className="text-gray-300 leading-relaxed">
                    As a Senior Software Engineer at Your Company, I oversee development practices across multiple
                    teams, ensuring adherence to best practices and driving efficiency through initiatives like modern
                    framework integration. My role involves standardizing development processes, defining strategies,
                    and mentoring team members to foster growth and high performance.
                  </p>

                  <div className="space-y-3">
                    <h4 className="text-white font-semibold">Responsibilities/Achievements:</h4>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <span className="text-red-500 mr-3 mt-2">▸</span>
                        <span className="text-gray-300">
                          Defined the development vision and strategic roadmap for the engineering department, aligning
                          initiatives with organizational goals.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-red-500 mr-3 mt-2">▸</span>
                        <span className="text-gray-300">
                          Governed development practices across multiple teams through regular code reviews and feedback
                          sessions to ensure adherence to standards.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-red-500 mr-3 mt-2">▸</span>
                        <span className="text-gray-300">
                          Provided strategic support to teams by defining tailored development, deployment, and
                          performance strategies.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-red-500 mr-3 mt-2">▸</span>
                        <span className="text-gray-300">
                          Organized and managed a portfolio of development initiatives, ensuring timely delivery and
                          quality standards.
                        </span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Work Section */}
      <section id="work" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center mb-12">
            <span className="text-red-500 font-mono text-xl mr-4">03.</span>
            <h2 className="text-3xl font-bold">Some Things I've Built</h2>
            <div className="flex-1 h-px bg-gray-700 ml-8"></div>
          </div>

          <div className="space-y-20">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              <div className="space-y-6">
                <p className="text-red-500 font-mono text-sm">Featured Project</p>
                <h3 className="text-2xl font-bold">E-Commerce Platform</h3>
                <div className="bg-[#2a3441] p-6 rounded-lg">
                  <p className="text-gray-300 leading-relaxed">
                    A full-stack e-commerce platform built with modern technologies including React, Node.js, and
                    PostgreSQL. Features include user authentication, payment processing, inventory management, and
                    real-time analytics dashboard.
                  </p>
                </div>
                <div className="flex flex-wrap gap-3 text-sm text-gray-300">
                  <span>React</span>
                  <span>Node.js</span>
                  <span>PostgreSQL</span>
                  <span>Stripe</span>
                  <span>AWS</span>
                </div>
              </div>
              <div className="relative">
                <Image
                  src="/placeholder.svg?height=300&width=500"
                  alt="E-Commerce Platform"
                  width={500}
                  height={300}
                  className="rounded-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto text-center">
          <div className="space-y-8">
            <div>
              <span className="text-red-500 font-mono text-lg">04. What's Next?</span>
              <h2 className="text-4xl font-bold mt-4">Get In Touch</h2>
            </div>
            <p className="text-gray-300 text-lg leading-relaxed">
              I'm always open to discussing new opportunities, interesting projects, or just having a chat about
              technology. Whether you have a question or just want to say hi, I'll try my best to get back to you!
            </p>
            <Button
              variant="outline"
              className="border-red-500 text-red-500 hover:bg-red-500 hover:text-white px-8 py-3 text-lg"
            >
              Say Hello
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 text-center text-gray-400 text-sm">
        <p>© {new Date().getFullYear()} Your Name. All rights reserved.</p>
      </footer>
    </div>
  )
}
